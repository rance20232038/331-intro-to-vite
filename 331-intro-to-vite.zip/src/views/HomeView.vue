<template>
  <div class="home">
    <h1>Home Page</h1>
  </div>
</template>

<script setup lang="ts">
console.log('HomeView setup executed')
</script>
