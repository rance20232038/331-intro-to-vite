<template>
  <div class="about">
    <h1>About Page</h1>
  </div>
</template>

<script setup lang="ts">
console.log('AboutView setup executed')
</script>
